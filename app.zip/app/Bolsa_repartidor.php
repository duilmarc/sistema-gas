<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bolsa_repartidor extends Model
{
    //
}
