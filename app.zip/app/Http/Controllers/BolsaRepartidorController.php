<?php

namespace App\Http\Controllers;

use App\Bolsa_repartidor;
use Illuminate\Http\Request;

class BolsaRepartidorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Bolsa_repartidor  $bolsa_repartidor
     * @return \Illuminate\Http\Response
     */
    public function show(Bolsa_repartidor $bolsa_repartidor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Bolsa_repartidor  $bolsa_repartidor
     * @return \Illuminate\Http\Response
     */
    public function edit(Bolsa_repartidor $bolsa_repartidor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Bolsa_repartidor  $bolsa_repartidor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bolsa_repartidor $bolsa_repartidor)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Bolsa_repartidor  $bolsa_repartidor
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bolsa_repartidor $bolsa_repartidor)
    {
        //
    }
}
