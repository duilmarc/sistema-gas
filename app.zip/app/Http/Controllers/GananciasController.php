<?php

namespace App\Http\Controllers;

use App\Ganancias;
use Illuminate\Http\Request;

class GananciasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Ganancias  $ganancias
     * @return \Illuminate\Http\Response
     */
    public function show(Ganancias $ganancias)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Ganancias  $ganancias
     * @return \Illuminate\Http\Response
     */
    public function edit(Ganancias $ganancias)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Ganancias  $ganancias
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Ganancias $ganancias)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Ganancias  $ganancias
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ganancias $ganancias)
    {
        //
    }
}
