<?php

namespace App\Http\Controllers;

use App\MotoCombustible;
use Illuminate\Http\Request;

class MotoCombustibleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MotoCombustible  $motoCombustible
     * @return \Illuminate\Http\Response
     */
    public function show(MotoCombustible $motoCombustible)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MotoCombustible  $motoCombustible
     * @return \Illuminate\Http\Response
     */
    public function edit(MotoCombustible $motoCombustible)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MotoCombustible  $motoCombustible
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MotoCombustible $motoCombustible)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MotoCombustible  $motoCombustible
     * @return \Illuminate\Http\Response
     */
    public function destroy(MotoCombustible $motoCombustible)
    {
        //
    }
}
