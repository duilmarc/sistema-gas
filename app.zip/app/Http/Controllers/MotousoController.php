<?php

namespace App\Http\Controllers;

use App\Motouso;
use Illuminate\Http\Request;

class MotousoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Motouso  $motouso
     * @return \Illuminate\Http\Response
     */
    public function show(Motouso $motouso)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Motouso  $motouso
     * @return \Illuminate\Http\Response
     */
    public function edit(Motouso $motouso)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Motouso  $motouso
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Motouso $motouso)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Motouso  $motouso
     * @return \Illuminate\Http\Response
     */
    public function destroy(Motouso $motouso)
    {
        //
    }
}
